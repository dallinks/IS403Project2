from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def indexPageView(request):
    return render(request,'pages/index.html')

def catalogPageView(request) :
    return render(request,'pages/catalog.html')

def cartPageView(request):
    return render(request,'pages/cart.html')