from django.urls import path 
from .views import  indexPageView,catalogPageView,cartPageView


urlpatterns = [
    
    path("",indexPageView,name = "index"),
    path('catalog/',catalogPageView,name = "catalog"),
    path('cart/',cartPageView,name="cart"),
]