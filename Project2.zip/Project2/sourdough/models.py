from django.db import models
from django.db.models.fields import CharField

# Create your models here.
class Customer(models.Model) :
    FirstName = models.CharField(max_length = 30,default=None)
    LastName = models.CharField(max_length = 30,default=None)
    ShippingAddress = models.CharField(max_length = 30,default=None)
    BillingAddress = models.CharField(max_length = 30,default=None)
    Phone = models.CharField(max_length = 30,default=None)
    Email = models.EmailField(max_length= 100,default=None)

class Order(models.Model) : 
    BreadName = models.CharField(max_length=(50))
    BreadID = models.IntegerField(default = 0)