from django.db import models
from django.db.models.fields import CharField, DecimalField, IntegerField
from django.db.models.fields.related import OneToOneField

# Create your models here.
class Customer(models.Model) :
    FirstName = models.CharField(max_length = 30,default=None)
    LastName = models.CharField(max_length = 30,default=None)
    ShippingAddress = models.CharField(max_length = 30,default=None)
    BillingAddress = models.CharField(max_length = 30,default=None)
    Phone = models.CharField(max_length = 30,default=None)
    Email = models.EmailField(max_length= 100,default=None)


class Items(models.Model) :
    BreadID = IntegerField(default = None)
    BreadName = models.CharField(max_length=(50))
    Description = models.CharField(max_length=255)

class Order(models.Model) : 
    BreadName = models.CharField(max_length=(50))
    Quantity = models.IntegerField(default=1)
    PastPrice = models.DecimalField(max_digits=4,decimal_places=2)
    BreadPic = models.ImageField(upload_to = 'photos')